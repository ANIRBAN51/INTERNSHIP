# Q1 Create a database named school_db
create database  if not exists school_db;
use school_db;
# Q2 Create a table in the above database as mentioned below:
#Students Table:
#Columns:
create table  if not exists `Students Table`
(
roll_no bigint primary key,
`name` varchar(200),
address  varchar(255),
contact varchar(50),
dob char(100),
class varchar(200)
);  

use school_db;
#Question 3: Add another column called Hobbies to the above table with type String and non-empty constraint
alter  table `students Table`
add column hobbies varchar(10) after class ;
#Question 4: Rename Contact to Emergency Contact in the above table.alter
alter table `students Table`
change column contact emergency_contact varchar(10);